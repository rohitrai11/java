package Association;

public class FDAccount {

	private int accountId;
	private float balance;
	
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public FDAccount(int id,float bal){
		this.accountId=id;
		this.balance=bal;
	}
	public void updateBalance(InterestCalculator interestCalc){
		this.setBalance(interestCalc.calculateInterest(this.getBalance())+this.getBalance());
		/*String h=this.accountId+"";
		System.out.println(h.length());*/
	}
}
