package application;

class ComplexNumber {
	// Code here
	private double real;
	private double imaginary;
	public double getReal() {
		return real;
	}
	public void setReal(double real) {
		this.real = real;
	}
	public double getImaginary() {
		return imaginary;
	}
	public void setImaginary(double imaginary) {
		this.imaginary = imaginary;
	}
	
	public ComplexNumber(double real,double imaginary){
		this.real=real;
		this.imaginary=imaginary;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(imaginary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(real);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ComplexNumber other = (ComplexNumber) obj;
		if (Double.doubleToLongBits(imaginary) != Double
				.doubleToLongBits(other.imaginary))
			return false;
		if (Double.doubleToLongBits(real) != Double
				.doubleToLongBits(other.real))
			return false;
		return true;
	}
	@Override
	public String toString() {
		System.out.println("The two numbers are : ");
		String s="ComplexNumber : ";
	if(this.getImaginary()>=0)
		return s+this.getReal()+"+"+this.getImaginary()+"i";
	else
		return s+this.getReal()+this.getImaginary()+"i";
	}
}

public class Tester {
	public static void main(String[] args) {
		// Code here
		ComplexNumber c=new ComplexNumber(2.0,-10.0);
		ComplexNumber c1=new ComplexNumber(2.0,-10.0);
		if(c.equals(c1))
			System.out.println("The two complex numbers are equal");
		else
			System.out.println("The two complex numbers are not equal");
		System.out.println(c.toString());
		System.out.println(c1.toString());
		
		ComplexNumber c2=new ComplexNumber(2.0,-10.0);
		ComplexNumber c3=new ComplexNumber(2.0,10.0);
		if(c2.equals(c3))
			System.out.println("The two complex numbers are equal");
		else
			System.out.println("The two complex numbers are not equal");
		System.out.println(c2.toString());
		System.out.println(c3.toString());
		
			
	}
}
