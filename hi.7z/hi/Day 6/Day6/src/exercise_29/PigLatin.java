package exercise_29;

public class PigLatin {
	
	public StringBuilder pigLatinConverter(String inputString){
		String s1=inputString.trim();
		String list[]=s1.split(" ");
		StringBuilder ans=new StringBuilder("");
		for(int i=0;i<list.length;i++){
		StringBuilder sb=new StringBuilder(list[i]);
		char s=sb.charAt(0);
		sb.delete(0,1);
		sb.append(s);
		sb.append("ay");
		ans.append(sb+" ");
		}
		return ans;
	}

}
