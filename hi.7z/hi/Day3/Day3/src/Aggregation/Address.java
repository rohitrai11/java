package Aggregation;

public class Address {

	private String street;
	private String city;
	private int zipcode;
	private String firstline;
	private String secondline;
	
	public String getFirstline() {
		return firstline;
	}

	public String getSecondline() {
		return secondline;
	}


	public Address(String first, String second, String street,String city,int zip){
		this.city=city;
		this.street=street;
		this.zipcode=zip;
		this.firstline=first;
		this.secondline=second;
	}

	public String getStreet() {
		return street;
	}


	public String getCity() {
		return city;
	}

	public int getZipcode() {
		return zipcode;
	}

}
