package exercise17;

public class Trainee implements Student {
	private int marksSecured;

	public Trainee(int marksSecured) {
		super();
		this.marksSecured = marksSecured;
	}
	
public void calcPercentage(){
	if(this.marksSecured<=400){
	double per=((double)this.marksSecured*100/Student.total_maximum_marks);
		System.out.println("The total aggregate percentage secured by the trainee is "+per);
	}
	else{
		System.out.println("Please enter the correct marks");
	}
	

}}
