package exercise_28;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c=new Customer();
		c.findDiscountAndName("Regular:Ram");
        c.findDiscountAndName("Privileged:Aditya");
	}

}
