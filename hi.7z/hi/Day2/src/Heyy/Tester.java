package Heyy;
import Heyy.Point;
//import Heyy.As;
public class Tester {

	As a= new As();
	As b=new As(0,0,1,1,2,5);
	Point p1=new Point(0,0);
	Point p2=new Point(1,1);
	Point p3=new Point(2,5);
	As c=new As(p1,p2,p3);
}
