package exercise17;

public class Intern implements Student {
	private int marksSecured;
	private int projectMarks;
	public Intern(int marksSecured, int projectMarks) {
		super();
		this.marksSecured = marksSecured;
		this.projectMarks = projectMarks;
	}
	
public void calcPercentage(){
	int marks=this.marksSecured+this.projectMarks;
	if(marks<=400){
	double per=((double)marks*100/this.total_maximum_marks);
	System.out.println("The total aggregate percentage secured by the intern is "+per);
	}
	else
		System.out.println("Please enter the correct marks");
}
}
