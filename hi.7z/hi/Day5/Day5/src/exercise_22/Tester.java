package exercise_22;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		Applicant a=new Applicant();
		a.setApplicantAge(17);
		a.setApplicantName("Raj");
		a.setPostApplied("Assistant");
		Validator v=new Validator();
		v.validate(a);

	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	}
}
