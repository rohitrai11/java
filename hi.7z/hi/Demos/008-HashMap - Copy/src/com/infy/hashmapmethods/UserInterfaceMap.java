package com.infy.hashmapmethods;


import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class UserInterfaceMap {

	public static void main(String[] args) {
		// Creating a hash map with containing employee details
		// Employee id is key and employee name is value
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		hMap.put(101, "Priya");
		hMap.put(102, "Priya");
		hMap.put(201, "Puneet");
		hMap.put(301, "Ajay");

		// Displaying elements of hashmap
	//System.out.println(hMap);
		//hMap.remove(101);
		//System.out.println(hMap);
		//System.out.println(hMap.size());
		
		
		Set<Integer> s=hMap.keySet();
		//iterating
		for (Integer integer : s) {
			String value=hMap.get(integer);
			System.out.println("Values   "+value+"Keys  "+integer);
			
		}
		
		
		Set<Entry<Integer, String>> entry=hMap.entrySet();
		
		for (Entry<Integer, String> entry2 : entry) {
			System.out.println(entry2.getValue());
			
		}
		

	}
}