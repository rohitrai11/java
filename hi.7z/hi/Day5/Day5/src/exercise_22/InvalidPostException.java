package exercise_22;

public class InvalidPostException extends Exception{
	public InvalidPostException(){
		super("Invalid Applicant Post");
	}
}