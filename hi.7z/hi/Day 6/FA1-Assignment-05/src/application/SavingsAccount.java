package application;

import org.apache.logging.log4j.Logger;

import resources.LogConfig;

public class SavingsAccount extends Account{
	// Code here
	private double minimumBalance;
	private int interestRate;
	final static Logger LOGGER=LogConfig.getLogger(SavingsAccount.class);
	
	public SavingsAccount(int accountNo,double minimumBalance,int interestRate,Customer customer,double balance){
		super.setAccountNo(accountNo);
		super.setBalance(balance);
		super.setCustomer(customer);
		this.interestRate=interestRate;
		this.minimumBalance=minimumBalance;
	}

	public double getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	public int getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(int interestRate) {
		this.interestRate = interestRate;
	}
	public void withdraw(double amount) throws Exception{
		try{
		double bal=super.getBalance()-amount;
		if(bal>this.minimumBalance){
			super.setBalance(bal);
			System.out.println("For "+super.getCustomer().getName());
			System.out.println("Account Balance : "+super.getBalance());
			System.out.println("Interest : "+this.calculateInterest());
			
		}
		else{
			System.out.println("For "+super.getCustomer().getName());
			System.out.println("Account Balance : "+super.getBalance());
			System.out.println("Interest : "+this.calculateInterest());
			throw new Exception("INSUFFICIENT_BALANCE");
			
		}
		}
		catch(Exception e){
			System.out.println("asd");
			LOGGER.info(e.getMessage());
			throw e;
			
		}
	}
	public double calculateInterest(){
		double si=this.getBalance()*this.getInterestRate()/100;
		return si;
	}
	
	
}