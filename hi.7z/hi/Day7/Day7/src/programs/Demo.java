package programs;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

class Demo {
//	public static Iterator getIterator(List list) {
//		Collections.reverse(list);
//		return list.iterator();
//	}

	public static void main(String[] args) {
//		List list = new ArrayList();
//		list.add("1"); list.add("2"); list.add("3");
//		Iterator iter = getIterator(list);
//		while(iter.hasNext())
//			System.out.print(iter.next() + ", ");
//		list.add("a");
//		Collections.rotate(list, 8);    
//		System.out.println(list);
//		list.add("3");
//		list.add("3");
//		list.add("3");
//		Set<String> uniqueItems = new HashSet<String>();
//		uniqueItems.addAll(list);
//		System.out.println(uniqueItems);
//	}}
		
//		Set<Integer,String> s1=new LinkedHashSet<>();
//		Set<String> s=new LinkedHashSet<>();
//		s.add("a");
//		s1.add(1,"a");
//		System.out.println(s);
		
//		Set set=new LinkedHashSet<>();
//		set.add(1,"a");
//		System.out.println(set);
		
//		Set<Integer> set = new HashSet<Integer>();
//        Integer i1 = 45;
//        Integer i2 = 46;
//        set.add(i1);
//        set.add(i1);
//        set.add(i2);
//        System.out.println(set);
//        System.out.print(set.size() + " ");
//        set.remove(i1);
//        System.out.print(set.size() + " ");
//        i2 = 47;
//        set.remove(i2);
//        System.out.println(set);
//        System.out.print(set.size() + " ");
		String password="xy";
		if(password.matches("[xyz]"))
			System.out.println("Yes");
	}
	}