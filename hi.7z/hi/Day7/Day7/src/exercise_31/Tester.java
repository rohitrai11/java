package exercise_31;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Participant> list=new ArrayList<>();
		
		Participant p=new Participant();
		p.setParticipantName("Hazel");
		p.setParticipantScore(29.75f);
		p.setParticipantTalent("Singing");
		
		Participant p1=new Participant();
		p1.setParticipantName("Hudson");
		p1.setParticipantScore(28f);
		p1.setParticipantTalent("Instrumental");
		
		Participant p2=new Participant();
		p2.setParticipantName("Enoch");
		p2.setParticipantScore(28.95f);
		p2.setParticipantTalent("Singing");
		
		Participant p3=new Participant();
		p3.setParticipantName("Bonsy");
		p3.setParticipantScore(26.67f);
		p3.setParticipantTalent("Dance");
		
		list.add(p);
		list.add(p1);
		list.add(p2);
		list.add(p3);
		int i=1;
		float m=0;
		String name="";
		for(Participant par:list){
			System.out.println("Participant "+i+":");
			System.out.println(par.getParticipantName());
			System.out.println(par.getParticipantTalent());
			System.out.println(par.getParticipantScore());
			i+=1;
			if(m<par.getParticipantScore()){
				m=par.getParticipantScore();
				name+=par.getParticipantName();
			}
		}System.out.println("The participant with highest score is:");
		System.out.println(name);
		System.out.println(m);
	}

}
