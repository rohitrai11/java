package fg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class exercise_33 {
public static void main(String[] args){
	Map<String,Integer> emp=new HashMap<>();
	String[] name={"Ajay", "Sachin", "Kamal", "Swati", "Ajay", "Rahul", "Amit"};

	for(String s:name){
		int count=1;
		if(!emp.containsKey(s)){
			emp.put(s, count);
					}
		else
			emp.put(s,((emp.get(s))+1));
	
		}
	System.out.println(emp);
	List<String> l=new ArrayList<>();
	l.add(emp);
	Collections.min(emp);
	}
}
