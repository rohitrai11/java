package Heyy;
import java.math.*;
import Heyy.Point;
public class As {
	
	private Point p1;
	private Point p2;
	private Point p3;
	
	public As(){
		this.p1=new Point(0,0);
		this.p2=new Point(1,1);
		this.p3=new Point(2,5);
		
	}
	
	public As(double x1, double y1, double x2, double y2, double x3, double y3){
		this.p1=new Point(x1,y1);
		this.p2=new Point(x2,y2);
		this.p3=new Point(x3,y3);
	}
	
	public As(Point p1,Point p2,Point p3){
		this.p1=p1;
		this.p2=p2;
		this.p3=p3;
		
	}
	public Point getP1() {
		return p1;
	}

	public void setP1(Point p1) {
		this.p1 = p1;
	}

	public Point getP2() {
		return p2;
	}

	public void setP2(Point p2) {
		this.p2 = p2;
	}

	public Point getP3() {
		return p3;
	}

	public void setP3(Point p3) {
		this.p3 = p3;
	}
	public double getPerimeter(){
		double per=p2.distance(p1)+p3.distance(p2)+p1.distance(p3);
		return per;
	}
	public double area(){
		double a=p2.distance(p1);
		double b=p3.distance(p2);
		double c=p1.distance(p3);
		double s=(a+b+c)/2;
		double ar=Math.sqrt(s*(s-a)*(s-b)*(s-c));
		return ar;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		As a2=new As();
		System.out.println("perimeter = "+a2.getPerimeter()+"      area = "+a2.area());
		As a=new As(2,5,0,0,5,0);
		System.out.println("perimeter = "+a.getPerimeter()+"      area = "+a.area());
		Point p1=new Point(2,5);
		Point p2=new Point(0,0);
		Point p3=new Point(5,0);
        As a1=new As(p1,p2,p3);
        System.out.println("perimeter = "+a1.getPerimeter()+"      area = "+a1.area());
	}

}

