package exercise_24;

public class Validator {
	
	public void validate(Employee emp)throws Exception{
		if(isValidAge(emp.getAge()))
				throw new InvalidAgeException();
		if(!isValidName(emp.getName()))
			throw new InvalidNameException();
	}
	public boolean isValidAge(int age){
		if(age>18 && age<60){
			return true;
		}
		return false;
	}
	public boolean isValidName(String name){
		if(name.length()>8){
			return true;
		}
		return false;
	}

}
