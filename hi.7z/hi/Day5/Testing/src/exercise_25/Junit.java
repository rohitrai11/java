package exercise_25;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class Junit {
@Rule
public ExpectedException ee=ExpectedException.none();
//public ExpectedException e=ExpectedException.none();

@Test
public void checkPrincipal() throws Exception{
	ee.expect(Exception.class);
	ee.expectMessage("INVALID.PrincipalAmount");
	
	InterestCalculator i=new InterestCalculator();
	i.calcSimpleInterest(0, 5, 12);
	
}
@Test
public void checkTime() throws Exception{
	ee.expect(Exception.class);
	ee.expectMessage("INVALID.TimePeriod");
	
	InterestCalculator i1=new InterestCalculator();
	i1.calcSimpleInterest(10, 0, 12);
}
@Test
public void checkRate() throws Exception{
	ee.expect(Exception.class);
	ee.expectMessage("INVALID.InterestRate");
	
	InterestCalculator i2=new InterestCalculator();
	i2.calcSimpleInterest(10, 5, 0);
}
@Test
public void check() throws Exception{

	InterestCalculator i2=new InterestCalculator();
	i2.calcSimpleInterest(10, 5, 10);
}
}