package test;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import application.Application;

public class ApplicationTest {
	
	@Rule
	public ExpectedException e=ExpectedException.none();
	
	@Test
	public void addStudentInvalidDepartment() throws Exception {
		// Write the code to test
		//Write test cases
		Application app=new Application();
		app.addStudent(student);
	}
	
	public void addStudentInvalidMarks() throws Exception {
		// Write the code to test
	}

	public void addStudentInvalidStudentId() throws Exception {
		// Write the code to test
	}
}
