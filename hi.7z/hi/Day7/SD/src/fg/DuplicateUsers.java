package fg;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

class DuplicateUsers {

	public static void main(String[] args) {
		List<User> userList = new ArrayList<User>();
		userList.add(new User("Max", "fgc123", "max@infy.com"));
		userList.add(new User("Mike", "hdgsh@", "imike@infy.com"));
		userList.add(new User("Mojo", "asdf45", "jojo@infy.com"));
		userList.add(new User("Michael", "oiort543", "imike@infy.com"));
		userList.add(new User("John", "ucantseeme", "jojo@infy.com"));
		userList.add(new User("Moby", "fgc123", "iammoby@infy.com"));
		
		List list=new ArrayList<>();
		
		for(User u:userList)
		    list.add(u.getEmail());
		   //System.out.println(list);
		Set<String> userSet = new LinkedHashSet<>();
		userSet.addAll(list);
		for(String user : userSet)
			System.out.println(user);
	}
}

class User {
	String username;
	String password;
	String email;
	
	public User(String username, String password, String email) {
		super();
		this.username = username;
		this.password = password;
		this.email = email;
	}
	public String getEmail(){
	    return this.email;
	}
	@Override
	public String toString() {
		return this.username + " : " + this.email;
	}
}

