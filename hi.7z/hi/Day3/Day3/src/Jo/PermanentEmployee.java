package Jo;

public class PermanentEmployee extends Employee {

	private double basicpay;
	private double hra;
	private int experience;
	
	public double getBasicpay() {
		return basicpay;
	}
	public void setBasicpay(double basicpay) {
		this.basicpay = basicpay;
	}
	public double getHra() {
		return hra;
	}
	public void setHra(double hra) {
		this.hra = hra;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public PermanentEmployee(int empid, String name, double basicpay,double hra,int experience){
		this.basicpay=basicpay;
		this.experience=experience;
		this.hra=hra;
		super.setEmpid(empid);
		super.setName(name);
	}
	public void calculateSalary(){
		double sal;
		if(this.experience<3)
			sal=this.basicpay+this.hra;
		else if(this.experience>=3 && this.experience<5)
			sal=this.basicpay+this.hra+0.05*this.basicpay;
		else if(this.experience>=5 && this.experience<10)
			sal=this.basicpay+this.hra+0.07*this.basicpay;
		else
			sal=this.basicpay+this.hra+0.12*this.basicpay;
		super.setSalary(sal);
		
	}
}
