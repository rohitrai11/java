package exercise_29;

public class Tester {
	public static void main(String[] args){
		PigLatin p=new PigLatin();
		System.out.println(p.pigLatinConverter("welcome to the next generation experience"));
	}
}
