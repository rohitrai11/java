package exercise_23;

public class Calculator {

    int add(String op1, String op2) {
    	Integer i1 = Integer.parseInt(op1);
        Integer i2 = Integer.parseInt(op2);
        return i1+i2;
    }

    int subtract(String op1, String op2) {
    	Integer i1 = Integer.parseInt(op1);
        Integer i2 = Integer.parseInt(op2);
        return i1-i2;
    }

    int multiply(String op1, String op2) {
    	Integer i1 = Integer.parseInt(op1);
        Integer i2 = Integer.parseInt(op2);
        return i1*i2;
    }

    int divide(String op1, String op2) {
            Integer i1 = Integer.parseInt(op1);
            Integer i2 = Integer.parseInt(op2);
            return i1/i2;
    }
    
    public static void main(String[] args){
    	try{
    		Calculator c=new Calculator();
    		int i=c.add("10", "12");
    		System.out.println(i);
    		int i1=c.divide("10", "0");
    		System.out.println(i);
    	}
    	catch(NumberFormatException e){
    		System.out.println(e.getMessage());
    	}
    	catch(ArithmeticException d){
    		System.out.println(d.getMessage());
    	}
    }
    
    
}