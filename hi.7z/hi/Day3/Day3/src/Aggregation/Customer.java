package Aggregation;

public class Customer {
	private Address address;
	private String customername;
	private double depositAmount;
	
	public Address getAddress() {
		return address;
	}
	public String getCustomername() {
		return customername;
	}
	public double getDepositAmount() {
		return depositAmount;
	}
	public boolean isValidAddress(){
		if(this.address.getZipcode()>=100000 && this.address.getZipcode()<=999999 ){
			return true;
		}
		else
			return false;
	}
	Customer(String name,Address address,double amount){
		this.customername=name;
		this.address=address;
		this.depositAmount=amount;
	}

}
