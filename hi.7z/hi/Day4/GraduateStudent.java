package exercise16;

public class GraduateStudent extends Student {
	
	public GraduateStudent(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	public void generateResult(){
		int[] marks=super.getTest();
		int sum=0;
		for(int i=0;i<marks.length;i++){
			sum+=marks[i];}
		double avgMarks=(sum/marks.length);
		if(avgMarks >=70)
			super.setResult("Pass");
		else
			super.setResult("Fail");
			
		
			
		
		
	

}}
