package Demo;

public class Tester {

	public static void main(String[] args){
		// TODO Auto-generated method stub
		Practice p =new Practice();
		try{
		float a=10;
		float b=0;
		if(b==0)
			throw new Exception("Exception");
		float r=a/b;
		System.out.println(r);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}finally{
			System.out.println("HI");
			System.exit(-1);
			System.out.println("HI");
		}

	}

}
