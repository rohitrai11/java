package application;
import org.apache.logging.log4j.Logger;

import resources.LogConfig;
public class CurrentAccount extends Account{
	// Code here
	private int overdraftAmount;
	final static Logger LOGGER=LogConfig.getLogger(CurrentAccount.class);
	public int getOverdraftAmount() {
		return overdraftAmount;
	}

	public void setOverdraftAmount(int overdraftAmount) {
		this.overdraftAmount = overdraftAmount;
	}
	
	public CurrentAccount(Customer customer,int overdraftAmount,int accountNo,double balance){
		super.setAccountNo(accountNo);
		super.setBalance(balance);
		super.setCustomer(customer);
		this.setOverdraftAmount(overdraftAmount);
	}
	public void withdraw(double amount) throws Exception{
		try{
			super.setBalance(super.getBalance()+this.getOverdraftAmount());
			double bal=(super.getBalance())-amount;
			double neg=-1000;
			if(bal>neg){
				System.out.println("For "+super.getCustomer().getName());
				System.out.println("Account Balance : "+amount);
				if(bal<=0)
				    System.out.println("Available balance after withdraw : 0.0");
				else
					System.out.println("Available balance after withdraw : "+bal);
			}
			else{
				System.out.println("For "+super.getCustomer().getName());
				System.out.println("Account Balance : "+amount);
			    if(bal<=0)
			    	System.out.println("Available balance after withdraw : 0.0");
			    else
			    	System.out.println("Available balance after withdraw : "+bal);
				throw new Exception("INSUFFICIENT_BALANCE");
			}
			}catch(Exception e){
				LOGGER.info(e.getMessage());
				
				this.testLog();
			}
	}

	public void testLog(){
		LOGGER.info("Low Balance");
	}
}
