package exercise_21;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			Triangle t=new Triangle(3,4,5);
			Triangle t1=new Triangle(3,1,5);
		}catch(Exception e){
			System.out.println("Exception caught");
		}

	}

}
