package Demo;

public class Practice {
	
	static{
		System.out.println("Static");
	}
	public static void main(String[] args) {
		int fiboCount = 6;
		int no1 = -1, no2 = 1;
		System.out.println("Fibonacci series:");
		for (int i = 0; i < fiboCount; i++) {
			int no3 = no1 + no2;
			System.out.print(no3 + " ");
			no2 = no3;
			no1 = no2;
		}
	}
}