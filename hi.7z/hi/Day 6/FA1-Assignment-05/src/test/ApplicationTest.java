package test;

import application.CurrentAccount;
import application.Customer;
import application.SavingsAccount;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class ApplicationTest {
	@Rule
	public ExpectedException ee=ExpectedException.none();
@Test	
	public void invalidSavingsWithdraw() throws Exception {
	ee.expect(Exception.class);
	ee.expectMessage("INSUFFICIENT_BALANCE");
		Customer c=new Customer();
		SavingsAccount s=new SavingsAccount(101,500,12,c,1000);
		s.withdraw(900);
	}
@Test	
	public void validSavingsWithdraw() throws Exception {
	
		
			Customer c=new Customer();
			SavingsAccount s=new SavingsAccount(101,500,12,c,1000);
			s.withdraw(400);
	}
	@Test
	public void invalidCurrentWithdraw() throws Exception {
		ee.expect(Exception.class);
		ee.expectMessage("INSUFFICIENT_BALANCE");
			Customer c=new Customer();
			CurrentAccount s=new CurrentAccount(c,500,101,2000);
			s.withdraw(4501);
	}
	
	public void validCurrentWithdraw() throws Exception {
		Customer c=new Customer();
		CurrentAccount s=new CurrentAccount(c,500,101,2000);
		s.withdraw(3500);
	}
}
