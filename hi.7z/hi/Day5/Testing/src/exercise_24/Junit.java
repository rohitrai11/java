package exercise_24;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class Junit {
@Rule
public ExpectedException ee=ExpectedException.none();
//public ExpectedException e=ExpectedException.none();

@Test
public void ageTest() throws Exception{
	ee.expect(InvalidAgeException.class);
	ee.expectMessage("Invalid Employee Age");
	
	
	Employee e1=new Employee();
	e1.setAge(32);
	e1.setName("KGBJKGJGJGKHL");
	Validator v=new Validator();
	v.validate(e1);
	
}

@Test
public void nameTest() throws Exception{
	ee.expect(InvalidNameException.class);
	ee.expectMessage("Invalid Employee Name");
	
	Employee e2=new Employee();
	e2.setAge(16);
	e2.setName("Raj");
	Validator v1=new Validator();
	v1.validate(e2);
}

}