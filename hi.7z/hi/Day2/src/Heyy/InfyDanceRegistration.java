package Heyy;

public class InfyDanceRegistration {
	
    private static int counter=10001;
    private String name;
    private long contactNumber;
    private String city;
    
    public String getName() {
		return name;
	}

    public InfyDanceRegistration(String name,long contactnumber,String city){
         this.name=name;
         this.contactNumber=contactnumber;
         this.city=city;
	
    }
    
    public String generateRegistrationId(){
    	int id=InfyDanceRegistration.counter;
    	InfyDanceRegistration.counter+=1;
    	return ("D"+id);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InfyDanceRegistration i=new InfyDanceRegistration("Raj",43264656,"Goa");
		String id=i.generateRegistrationId();
		System.out.println("Hi "+i.getName()+"! Your Registration Id is : "+id);
		
		InfyDanceRegistration i1=new InfyDanceRegistration("Maya",43264656,"Goa");
		String id1=i1.generateRegistrationId();
		System.out.println("Hi "+i1.getName()+"! Your Registration Id is : "+id1);
	}

}
