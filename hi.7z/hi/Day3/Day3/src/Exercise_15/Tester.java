package Exercise_15;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Traveller t=new Traveller("Raj","1001");
SeniorTraveller s=new SeniorTraveller("Joey","2001",70);
t.displayDetails();
s.displayDetails();
SeniorTraveller s1=new SeniorTraveller("Jack","2001",45);
s1.displayDetails();
	}

}
