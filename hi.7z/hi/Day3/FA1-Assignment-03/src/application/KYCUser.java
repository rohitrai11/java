package application;

public class KYCUser extends User {
	private int rewardPoints;
	
	public int getRewardPoints() {
		return rewardPoints;
	}

	public void setRewardPoints(int rewardPoints) {
		this.rewardPoints = rewardPoints;
	}

	// Code here
	public KYCUser(int id,String username,String email,double walletBalance){
		super(id,username,email,walletBalance);
	}
	@Override
	public boolean makePayment(double billAmount){
		if(super.makePayment(billAmount)){
			this.rewardPoints+=(int)(0.10*billAmount);
			//this.setRewardPoints(p);
			return true;
		}
		else
			return false;
	}
}
