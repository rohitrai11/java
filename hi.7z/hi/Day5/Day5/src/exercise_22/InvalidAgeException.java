package exercise_22;

public class InvalidAgeException extends Exception{
	public InvalidAgeException(){
		super("Invalid Applicant Age");
	}
}