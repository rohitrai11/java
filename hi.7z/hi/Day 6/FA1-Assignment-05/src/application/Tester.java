package application;
import resources.AppConfig;
public class Tester {
	public static void main(String[] args) throws Exception {
		// Code here
		try{
		Customer c=new Customer();
		c.setName("John");
		SavingsAccount s=new SavingsAccount(101,500,12,c,1000);
		System.out.println("Name : "+c.getName()+"     "+"Balance : "+s.getBalance()+"     Rate : "+s.getInterestRate());
		s.withdraw(1600);
		
		Customer c1=new Customer();
		c1.setName("Jenny");
		CurrentAccount ca=new CurrentAccount(c1,500,102,2000);
		System.out.println("Name  : "+c1.getName()+"     Balance : "+ca.getBalance());
	
		ca.deposit(1500);
		ca.withdraw(4000);
		}
		catch(Exception e){
			String str=(String) AppConfig.PROPERTIES.get(e.getMessage());
			System.out.println(str);
			
		}

	
		
	
}
}