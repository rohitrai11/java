package com.infy.hashset;

import java.util.HashSet;
import java.util.Set;

public class UserInterface {

	public static void main(String[] args) {
		//Creating a hash set containing names of cities
		Set<Student> cities=new HashSet<Student>();	
		Student s1=new Student();
		s1.setId(1);
		s1.setName("Tom");
		cities.add(s1);
		System.out.println(cities);
		for (Student student : cities) {
			System.out.println(cities);
		}
		for (int i = 0; i < cities.size(); i++) {
			String value=cities.toString();
			//System.out.println(value);
			//System.out.println(s1.getId()+s1.getName());
		}
	
		//System.out.println(s1.getName());
		//Adding strings to hash set
		/*cities.add("Delhi");
		cities.add("Mumbai");
		cities.add("Kolkatta");
		cities.add("delhi");			
		cities.add("Delhi");
		cities.add("Mysuru");*/
		//System.out.println("Elements of HashSet are ");
		//Displaying the elements in the hash set
		//System.out.println(cities);	
		
		
	
	}

}
