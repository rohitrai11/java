package application;

public interface Certification {
	public static final double regular_course_fee=2000;
	public static final double crash_course_fee=5000;
	public double calculateFee();
}
