package exercise_24;

public class InvalidNameException extends Exception{
	public InvalidNameException(){
		super("Invalid Employee Name");
	}
}
