package Exercise_15;

public class SeniorTraveller extends Traveller {
	private int age;
	public SeniorTraveller(String name,String id,int age){
		super(name,id);
		this.age=age;
	}
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
@Override
	public void calculateFare(){
		double discount=0.0;
		if(this.getAge()<=50 && this.getAge()<=65)
			discount=0.10;
		if(this.getAge()>65)
			discount=0.15;
		super.setFare((2000+(2000*0.1136))*(1-discount));
		if(this.getAge()<50)
			super.setFare(-1);
	}
	@Override
	public void displayDetails(){
		this.calculateFare();
		if(this.getAge()<50)
			System.out.println("Sorry "+super.getName()+", age should be 50 or more to avail senior traveller's concession");
		else{
			System.out.println("Senior Traveller Details");
			System.out.println("Traveller name : "+super.getName());
			System.out.println("Traveller Id : "+super.getId());
			System.out.println("Cost of Travel : "+super.getFare());
		}
	}

}
