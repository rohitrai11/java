package com.infy.hashmap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class UserInterfaceMap {

	public static void main(String[] args) {
		// Creating a hash map with containg employee details
		// Employee id is key and employee name is value
		Map<Integer, String> hMap = new TreeMap<Integer, String>();
		hMap.put(101, "Priya");
		hMap.put(301, "Priya");
	
		//hMap.put(null, null);//entry
		hMap.put(201, "Hello");
/*		hMap.put(null, "Hi");*/
		//hMap.put(501, "Deepa");
		//Displaying elements of hashmap
		System.out.println("Elements of HashMap are" + hMap);
	
		
	}
}