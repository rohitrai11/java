package exercise_31;

public class Participant {
	
	private String ParticipantName;
	private String ParticipantTalent;
	private float ParticipantScore;
	
	public String getParticipantName() {
		return ParticipantName;
	}
	public void setParticipantName(String participantName) {
		ParticipantName = participantName;
	}
	public String getParticipantTalent() {
		return ParticipantTalent;
	}
	public void setParticipantTalent(String participantTalent) {
		ParticipantTalent = participantTalent;
	}
	public float getParticipantScore() {
		return ParticipantScore;
	}
	public void setParticipantScore(float participantScore) {
		ParticipantScore = participantScore;
	}

}
