package application;

import java.time.LocalDate;
import java.util.List;

import org.apache.logging.log4j.Logger;

import resources.LogConfig;

public class Validator {
	final static Logger LOGGER=LogConfig.getLogger(Validator.class);
	public void validate(Booking booking) throws Exception {
		// Use isValidBatchName, isValidCourseName, isValidAssessmentDate, isValidAssessmentType, isValidEmailId to validate the booking details
		// For invalid inputs throw exceptions with the corresponding messages
		
		try{
			if (!isValidAssessmentDate(booking.getAssessmentDate()))
				throw new Exception("Validator.INVALID_ASSESSMENT_DATE ");
			else if(!isValidAssessmentType(booking.getAssessmentType()))
				throw new Exception("Validator.INVALID_ASSESSMENT_TYPE");
			else if(!isValidBatchName(booking.getBatchName()))
				throw new Exception("Validator.INVALID_BATCH_NAME");
			else if(!isValidCourseName(booking.getCourseName()))
				throw new Exception("Validator.INVALID_COURSE_NAME");
			else if(!isValidEmailId(booking.getTraineesList()))
				throw new Exception("Validator.INVALID_EMAIL_ID");
			
		}catch(Exception e)
		{
			LOGGER.debug(e.getMessage());
			throw e;
		}
	}
	
	public Boolean isValidBatchName(String batchName) {
		String reg="(JEE|MS|IVS)-(RT1|RT2)-(CS|NCS)";
		if (batchName.matches(reg))
			return true;
		return false;
	}

	public Boolean isValidCourseName(String courseName) {
	 if(courseName.length()==3&&courseName.substring(0,2).equals("FA")&&Integer.parseInt(courseName.substring(2))>0&&Integer.parseInt(courseName.substring(2))<10)
			return true;
		return false;
	}
	
	public Boolean isValidAssessmentDate(LocalDate assessmentDate) {
		if(assessmentDate.getDayOfWeek().getValue()!=6||assessmentDate.getDayOfWeek().getValue()!=7){
		if(assessmentDate.isAfter(LocalDate.now())&& assessmentDate.isBefore(LocalDate.now().plusDays(9)))
			return true;
		}
		return false;
	}

	
	public Boolean isValidAssessmentType(String assessmentType) {
		if(assessmentType.equals("Objective")||assessmentType.equals("Hands-on"))
			return true;
		return false;
	}

	public Boolean isValidEmailId(List<Trainee>traineesList) {
		for(Trainee trainee:traineesList){
			if(!trainee.getEmailId().matches("[a-zA-Z]+_"+trainee.getEmpNo()))
				return false;
			else
				continue;
		}
		return true;
	}
}
