package application;

public class EPayWallet {
	//
	public static void processPaymentByUser(User user, double billAmount){
		
		if(user.makePayment(billAmount)){
			
			System.out.println("Congratulations "+user.getUsername()+", payment of "+billAmount+" was successful");	
		}
	else{
		System.out.println("Sorry "+user.getUsername()+", not enough balance to make payment");
	}
		if(user.getWalletBalance()>billAmount)
			user.setWalletBalance(user.getWalletBalance()-billAmount);
		System.out.println("Your wallet balance is "+user.getWalletBalance());
		if(user instanceof KYCUser){
			int a=((KYCUser) user).getRewardPoints();
			System.out.println("You have "+a+" reward points");	
}
}
}