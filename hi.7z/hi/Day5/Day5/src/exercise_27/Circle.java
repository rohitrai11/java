package exercise_27;

public class Circle {

	public static final float pi=3.14f;
	private float radius;
	
	public Circle(float radius){
		this.radius=radius;
	}
	public Circle(){
		super();
	}
	public float calculateArea(){
		return (pi*this.radius*this.radius);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(radius);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Circle other = (Circle) obj;
		if (Float.floatToIntBits(radius) != Float.floatToIntBits(other.radius))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return ("The radius is "+this.radius+" and the area is "+this.calculateArea());
	}	
}
