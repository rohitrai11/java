package application;

public class Tester {
	public static void main(String[] args) {
		// Code here
		int price=0;
		String[] cart={"round-neck", "collared", "hooded", "round-neck", "round-neck"};
		for(int i=0;i<cart.length;i++){
			if(cart[i]=="round-neck")
				price+=200;
			else if(cart[i]=="collared")
				price+=250;
			else if(cart[i]=="hooded")
				price+=300;
			else
				price+=0;
		}
		double discount=0.0;
		if(cart.length<5)
			discount=0.0;
		else if(cart.length>=5 && cart.length<=10)
			discount=0.10;
		else
			discount=0.20;
		double amount=price-(price*discount) ;
		System.out.println("Final price is Rs. "+amount);
	}
}
