package application;

public class RegularCourseCertification extends RRTechnicalCertification implements Certification{
	private int courseDuration;

	public RegularCourseCertification(String studentName,String courseName,int admissionTestMarks,int courseDuration) {
		super(studentName,courseName,admissionTestMarks);
		this.courseDuration = courseDuration;
	}

	public int getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(int courseDuration) {
		this.courseDuration = courseDuration;
	}
	@Override
	public void generateRegistrationId(){
		super.setRegistrationId(RRTechnicalCertification.counter);
		RRTechnicalCertification.counter+=1;
	}
	
	@Override
	public double calculateFee(){
		int marks=super.getAdmissionTestMarks();
		double discount=0;
		if(marks>=90)
			discount=0.10;
		else if(marks>=75 && marks<=89)
			discount=0.05;
		else
			discount=0;
		double total_fee=Certification.regular_course_fee*this.getCourseDuration()*(1-discount);
		return total_fee;
	}	
}
