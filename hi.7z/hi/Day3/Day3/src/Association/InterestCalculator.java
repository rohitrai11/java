package Association;

public class InterestCalculator {

	private int timeInYears;
	private float rateofInterest;
	
	public int getTimeInYears() {
		return timeInYears;
	}
	public void setTimeInYears(int timeInYears) {
		this.timeInYears = timeInYears;
	}
	public float getRateofInterest() {
		return rateofInterest;
	}
	public void setRateofInterest(float rateofInterest) {
		this.rateofInterest = rateofInterest;
	}
	public InterestCalculator(int time,float rate){
		this.rateofInterest=rate;
		this.timeInYears=time;
	}
	public float calculateInterest(float principal){
		float si=this.rateofInterest*this.timeInYears*principal/100;
		return si;
	}
}
