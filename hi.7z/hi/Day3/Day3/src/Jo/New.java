package Jo;

class New {
    New(int x) {
        System.out.println("Request for loan");
    }
}