package Aggregation;

public class Tester_cust {
public static void main(String[] args){
	Address a=new Address("Raj","Singhania","Banglore","Karnataka",203401);
	Customer c=new Customer("Riya",a,10000);
    if(c.isValidAddress()){
    	System.out.println("Name : "+c.getCustomername());
    	System.out.println("Address : "+c.getAddress().getCity());
    	System.out.println("Deposit Amount : "+c.getDepositAmount());
    	System.out.println("Congratulations");
    }
    else
    	System.out.println("Invalid Pincode");
	System.out.println(c instanceof Customer);
}
}