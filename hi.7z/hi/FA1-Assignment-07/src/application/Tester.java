package application;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import java.util.Map.Entry;

public class Tester {
	public static void main(String[] args) {
		// Code here
		List<Dog> dogList=new ArrayList<>();
		dogList.add(new Dog("Companion",7));
		dogList.add(new Dog("Companion",10));
		dogList.add(new Dog("Herding",4));
		dogList.add(new Dog("Herding",10));
		dogList.add(new Dog("Herding",10));
		dogList.add(new Dog("Terrier",15));
		dogList.add(new Dog("Terrier",15));
		dogList.add(new Dog("Terrier",9));
		getDogStatistics(dogList);
	}
	
	public static TreeMap<Dog, Integer> getDogStatistics(List<Dog> dogList) {
		// Code here
		TreeMap<String, Integer> stats=new TreeMap<String,Integer>();
		TreeMap<Dog, Integer> f=new TreeMap<Dog, Integer>();
		for(Dog d:dogList){
		stats.put(d.getBreed(), d.getAgeInMonths());
		}
		
		Set<Entry<String,Integer>> entrySet = stats.entrySet();
		 for(Map.Entry<String, Integer> entry : entrySet){
			 System.out.println(entry.getKey()+"        "+entry.getValue());
		
	}
		 return f;
}
}
