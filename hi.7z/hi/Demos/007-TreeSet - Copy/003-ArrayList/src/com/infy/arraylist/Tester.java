package com.infy.arraylist;

import java.util.LinkedList;
import java.util.List;

class ListTester {
    public static void main(String args[]) {
        LinkedList<String> obj = new LinkedList<String>();
        obj.add("A");
        obj.add(10);
        obj.add("C");
        obj.addFirst("D");
        System.out.println(obj);
        
        List<E> newList=new LinkedList<E>()
     }
}
