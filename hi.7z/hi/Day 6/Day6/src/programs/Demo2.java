package programs;
//import junit.framework.Assert;
//
//import org.junit.Test;
//public static void main(String[] args){
//String s1="      AB CD  ";
//String s2=new String("AB");
//String s3=new String("AB");
//System.out.println(Character.isAlphabetic('AB'));
//String[] s=s1.split(" ");
//System.out.println(s[1]);
//s1.trim();
//System.out.println(s1.substring(7));
//System.out.println(s2.equalsIgnoreCase("ab"));

//System.out.println(String.valueOf("a"));
//}


//public class JunitTest {
//@Test
//public void designationTest(){
//Assert.assertEquals(500.10,500.05,0.05);
//
//}
//}
public class Demo2 {
	public void match(String s){
		if(s.matches("*.bye.*"))
			System.out.println("Yes");
		System.out.println("No");
	}
	
public static void main(String args[]){
Demo2 d=new Demo2();
	d.match("bk bye j");
}
}
