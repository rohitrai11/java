package Jo;

public class Test {
public static void main(String[] args){
    //Reg g=new New();
	@SuppressWarnings("unused")
	Reg g=new Reg();
}
}
