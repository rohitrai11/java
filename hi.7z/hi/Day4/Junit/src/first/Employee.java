package first;

public class Employee {
private String name;
private int salary;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}

public boolean designation(String name,int salary){
	this.setSalary(salary);
	this.setName(name);
	if(this.getSalary()>10000){
		System.out.println(this.getName()+"Rich");
		return true;}
	else{
		System.out.println(this.getName()+"Poor");
		return false;}
}
	
}
