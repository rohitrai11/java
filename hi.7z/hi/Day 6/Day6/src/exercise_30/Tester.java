package exercise_30;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebAddressValidator w=new WebAddressValidator ();
		//boolean r=w.isValidWebAddress("http://www.infosys.com");
		boolean r=w.isValidWebAddress("http.www.infosys.au");
		if(r)
			System.out.println("You have entered a valid web address");
		else
			System.out.println("You have entered an invalid web address");
	}

}
