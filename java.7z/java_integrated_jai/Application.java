package application;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.Logger;

import resources.LogConfig;


public class Application {
	final static Logger LOGGER=LogConfig.getLogger(Application.class);
	Validator v = new Validator();
	DataProvider d = new DataProvider();
	
	public Integer bookAssessment(Booking booking) throws Exception {
		try{
		v.validate(booking);
		booking.setDurationInMin(getDurationOfExam(booking.getAssessmentType()));
		return d.bookAssessment(booking);	
		}
		catch(Exception e){
			throw e;
		}
	}
	
	public Integer getDurationOfExam(String assessmentType) {
		Map<String,Integer> exam=d.getExamDuration();
		return exam.get(assessmentType);
		
	}
	
	public List<Report> getAssessmentReport(String batchName) throws Exception {
		
		List<Report> re=new ArrayList<Report>();
		try{
			List<Report> report = d.getAssessmentReport();
			for (Report r:report){
				if (r.getBatchName().equals(batchName)&&r.getAssessmentDate().isAfter(LocalDate.now()))
					re.add(r);
			}
			if(re.isEmpty())
				throw new Exception("Application.NO_RECORDS_FOUND");
		}catch(Exception e){
			LOGGER.debug(e.getMessage());
			throw e;
		}
		return re;
	}
}
