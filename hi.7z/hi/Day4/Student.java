package exercise16;

abstract public class Student {
	private String name;
	private int[] test=new int[4];
	private String result;
	
	
	
	 public Student(String name) {
		this.name = name;
	}
	 



	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public int[] getTest() {
		return test;
	}





	

	String getResult() {
		return result;
	}




	public void setTestScore(int testNumber,int testScore) {
		this.test[testNumber]=testScore;
	}




	public void setResult(String result) {
		this.result = result;
	}




	abstract public void generateResult();
		 
	 

}
