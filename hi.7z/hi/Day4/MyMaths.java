package exercise18;
import java.math.*;

public class MyMaths {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		mean(2,4,5,7,6);
		deviation(2,4,5,7,6);
}
	public static void mean(int ...x){
		int sum=0;
		for(int i=0;i<x.length;i++)
			sum+=x[i];
		double mean1=(double)sum/x.length;
		System.out.println("Mean is "+mean1);
		
	}
	public static void deviation(int ...x){
		int sum=0;
		double per=0;
		double devi=0;
		for(int i=0;i<x.length;i++)
			sum+=x[i];
		double mean1=(double)sum/x.length;
		for(int i=0;i<x.length;i++)
			per+=Math.pow(((double)x[i]-mean1), 2);
		devi=Math.sqrt(per/x.length);
		System.out.println("Standard Deviation is "+devi);
		
	}

}
