package dg;

import java.time.DayOfWeek;
import java.time.LocalDate;

public class Demo {
enum pizzaSize {small, medium,large};
private pizzaSize size;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
LocalDate d=LocalDate.now();
		
		System.out.println(d.getDayOfWeek());
	}

}

