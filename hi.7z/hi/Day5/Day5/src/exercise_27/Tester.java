package exercise_27;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Circle c=new Circle(10);
Circle c1=new Circle(10);
System.out.println(c.toString());
if(c.equals(c1)){
	System.out.println("The two circles are equal");
	System.out.println(c1.toString());}
else
	System.out.println("The two circles are not equal");

	}

}
