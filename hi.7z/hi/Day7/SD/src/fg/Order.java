package fg;


import java.util.ArrayList;
//import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

public class Order {
public static void main(String[] args){
	Order order=new Order();
	List<String> orders = new ArrayList<String>(); 
	orders.add("a");
	orders.add("b");
	orders.add("c");
	System.out.println(orders);
	orders.remove(0);
	System.out.println(orders);
	
	System.out.println(Collections.max(orders));
	List list = new ArrayList();
	list.addAll(orders);
	list.add(1);
	System.out.println(list);
	
	Iterator<String> iterator = orders.iterator();             // Getting the iterator from a list

	System.out.println("Elements in the list: ");
	while(iterator.hasNext()) {
	    System.out.println(iterator.next());
	}
	
	for(String o:orders)
		System.out.println(o);
	
	ListIterator<String> iterator1 = orders.listIterator();             // Getting the iterator from a list

	System.out.println("Elements in the list: ");
	while(iterator1.hasNext()) {
	    System.out.println(iterator1.next());
	}
	while(iterator1.hasPrevious()) {
	    System.out.println(iterator1.previous());
	}
	list.remove(2);
	list.add("b");
	list.add("b");
	list.add("d");
	Set<String> uniqueItems = new HashSet<String>();
	uniqueItems.addAll(list);
	
	Iterator set=uniqueItems.iterator();
	while(set.hasNext())
		System.out.println(set.next());
	
	Map<String, Integer> itemMap = new HashMap<String, Integer>();

	for(String item : orders) {
		//System.out.println(item);
	    if(itemMap.containsKey(item)) {
	        itemMap.put(item, itemMap.get(item) + 1);
	    }
	    else itemMap.put(item, 1);
	}
}
}
