package exercise_21;

public class IllegalDimensionException extends Exception{
	public IllegalDimensionException(){
		super("Illegal triangle. The sum of two sides must be greater than other side");
	}
}

