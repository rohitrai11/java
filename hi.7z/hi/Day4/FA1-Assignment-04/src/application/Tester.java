package application;

public class Tester {
	// Code here
	public static void main(String args[]){
	RegularCourseCertification r=new RegularCourseCertification("Rakesh","J2EE",85,5);
	r.generateRegistrationId();
	System.out.println(r.getRegistrationId());
	System.out.println(r.calculateFee());
	CrashCourseCertification c=new CrashCourseCertification("Roshan","Angular",71);
	c.generateRegistrationId();
	System.out.println(c.getRegistrationId());
	System.out.println(c.calculateFee());
}
}