package com.infy.linkedlist;

import java.util.LinkedList;
import java.util.List;


public class UserInterface {
	public static void main(String[] args) {
		List list = new LinkedList<>();
		list.add(200);
		list.add("Sachin");
		list.add("Sachin");
		list.add(1,"Virat");
		list.add(2,"Ashwin");
		list.add(1, "Yuvraj");
		System.out.println("A list of players in a LinkedList");
		for (int index = 0; index < list.size(); index++) {
			System.out.println(list.get(index));
		}
	}

}
