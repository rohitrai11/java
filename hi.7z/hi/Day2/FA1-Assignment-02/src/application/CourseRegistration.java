package application;

public class CourseRegistration {
	private String studentName;
	private int registrationId;
	private float qualifyingMarks;
	private double courseFee;
	private int courseId;
	private boolean hostelRequired;
	
	
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public float getQualifyingMarks() {
		return qualifyingMarks;
	}
	public void setQualifyingMarks(float qualifyingMarks) {
		this.qualifyingMarks = qualifyingMarks;
	}
	public double getCourseFee() {
		return courseFee;
	}
	public void setCourseFee(double courseFee) {
		this.courseFee = courseFee;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public boolean isHostelRequired() {
		return hostelRequired;
	}
	public void setHostelRequired(boolean hostelRequired) {
		this.hostelRequired = hostelRequired;
	}
	// Code here
	
	
	public boolean validateMarks(){
		float m=getQualifyingMarks();
		if(m>=65 && m<=100){
			return true;
		}
		else
			return false;
	}
	
	public boolean validateCourseId(){
		int c=getCourseId();
		if(c==1001 || c==1002 || c==1003 || c==1004 || c==1005){
			return true;
		}
		else
			return false;
	}
	
	public void calculateCourseFee(){
		float m=getQualifyingMarks();
		boolean v=validateMarks();
		boolean c=validateCourseId();
		double fee=getCourseFee();
		double d=0;
		if(v==true && c==true){
		if(m>=65 && m<=69)
			d=0.05;
		else if(m>=70 && m<=84)
			d=0.10;
		else
			d=0.15;
		double total=fee-(fee*d);
		System.out.println("Student Name : "+getStudentName());
		System.out.println("Course Id : "+getCourseId());
		System.out.println("Qualifying Exam Marks : "+getQualifyingMarks());
		System.out.println("Student's Registration Id : "+getRegistrationId());
		System.out.println("Total Course Fee : "+total);
		if(isHostelRequired()==true)
		System.out.println("Hostel Required : Yes");
		else 
			System.out.println("Hostel Required : No");
		}
		else if(v==false && c==true)
			System.out.println("Marks is less than 65. You are not eligible for admission!!");
		else
			System.out.println("Invalid Course Id. Please try again!!");
	}
}
