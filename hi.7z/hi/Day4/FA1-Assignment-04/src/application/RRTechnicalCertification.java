package application;
	
abstract public class RRTechnicalCertification {
	private String courseName;
	private String studentName;
	private int registrationId;
	private int admissionTestMarks;
	public static int counter=1001;
	public RRTechnicalCertification(String studentName,String courseName,int admissionTestMarks) {
		this.courseName = courseName;
		this.studentName = studentName;
		this.admissionTestMarks = admissionTestMarks;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getStudentName() {
		return studentName;
	}
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public int getAdmissionTestMarks() {
		return admissionTestMarks;
	}
	public void setAdmissionTestMarks(int admissionTestMarks) {
		this.admissionTestMarks = admissionTestMarks;
	}
	abstract public void generateRegistrationId();
	abstract public double calculateFee();	
}
