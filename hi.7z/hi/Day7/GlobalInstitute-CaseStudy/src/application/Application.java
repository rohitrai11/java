package application;

import java.util.ArrayList;
import java.util.List;

import resources.LogConfig;

public class Application {

	// can have status as 'P' only if all 3 marks are 50 and above
	public String addStudent(Student student) throws Exception {
		Validator v=new Validator();
		try{
			v.validate(student);
			char temp='P';
			//logic
			DataProvider data=new DataProvider();
			return data.addStudent(student);
		}
		catch(Exception e){
			LogConfig.getLogger(this.getClass().error(e.getMessage()));
			throw e;
		}
		
		return null;
	}

	public String calculateGrade(StudentReport studentReport) throws Exception {
		return null;
	}

	public List<StudentReport> getGradesForStudentsInRange(String range) throws Exception {
		List<StudentReport> finalList = new ArrayList<>();
		//dataprovider obj with try n invoke 2nd method
		//split n find lower n upper limit then call getAllStudent() n use advance loop
		return null;
	}
}
