package application;

import java.util.Collections;

public class Dog implements Comparable<Dog>{
	// Code here
	private String breed;
	private Integer ageInMonths;
	
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public Integer getAgeInMonths() {
		return ageInMonths;
	}
	public void setAgeInMonths(Integer ageInMonths) {
		this.ageInMonths = ageInMonths;
	}
	public Dog(String breed,Integer ageInMonths){
		this.setAgeInMonths(ageInMonths);
		this.setBreed(breed);
	}
	@Override
	public int compareTo(Dog o) {
		// TODO Auto-generated method stub
		if((this.getAgeInMonths()>o.getAgeInMonths()) &&(getBreed().compareTo(o.getBreed()) >0))
				return 1;
		else if((this.getAgeInMonths()>o.getAgeInMonths()) &&(getBreed().compareTo(o.getBreed()) >=0))
			return -1;
		else if((this.getAgeInMonths()>o.getAgeInMonths()) &&(getBreed().compareTo(o.getBreed()) ==0))
			return 0;
		else if(this.getAgeInMonths()==o.getAgeInMonths() && (getBreed().compareTo(o.getBreed()) ==0))
			return 0;
		else if(this.getAgeInMonths()==o.getAgeInMonths() && (getBreed().compareTo(o.getBreed()) >0))
			return 1;
		else if(this.getAgeInMonths()==o.getAgeInMonths() && (getBreed().compareTo(o.getBreed()) <0))
			return -1;
		else if(this.getAgeInMonths()<o.getAgeInMonths() && (getBreed().compareTo(o.getBreed()) <0))
			return -1;
		else if(this.getAgeInMonths()<o.getAgeInMonths() && (getBreed().compareTo(o.getBreed()) >0))
			return 1;
		else
			return 0;
		
		//Collections.sort(list);
	}
	
}
