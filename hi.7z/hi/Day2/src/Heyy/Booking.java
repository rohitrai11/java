package Heyy;

public class Booking {
	
	private String customerEmail;
	private int seatsRequired;
	private boolean isBooked;
	private static int seatsAvailable=400;
	
	public Booking(String customerEmail,int seatsrequired){
		this.customerEmail=customerEmail;
		this.seatsRequired=seatsrequired;
		if(this.seatsRequired<=this.seatsAvailable){
			this.seatsAvailable-=this.seatsRequired;
			this.isBooked=true;
		}
		else
			this.isBooked=false;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public int getSeatsRequired() {
		return seatsRequired;
	}

	public void setSeatsRequired(int seatsRequired) {
		this.seatsRequired = seatsRequired;
	}

	public boolean isBooked() {
		return isBooked;
	}

	public void setBooked(boolean isBooked) {
		this.isBooked = isBooked;
	}

	public static int getSeatsAvailable() {
		return seatsAvailable;
	}

	public static void setSeatsAvailable(int seatsAvailable) {
		Booking.seatsAvailable = seatsAvailable;
	}

	public void showbookingstatus(){
		if(this.isBooked()==true){
			System.out.println(this.getSeatsRequired()+" seats successfully booked for "+this.getCustomerEmail());
		}
		else{
			System.out.println("Sorry "+this.getCustomerEmail()+", not enough seats! Seats available: "+this.getSeatsAvailable());
		}
			
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Booking b=new Booking("jack@infy.com",100);
b.showbookingstatus();
Booking b1=new Booking("jill@infy.com",200);
b1.showbookingstatus();
Booking b2=new Booking("jamie@infy.com",200);
b2.showbookingstatus();
	}

}
