package exercise_24;

public class InvalidAgeException extends Exception{
	public InvalidAgeException(){
		super("Invalid Employee Age");
	}

}
