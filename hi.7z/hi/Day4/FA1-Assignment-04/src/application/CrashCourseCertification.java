package application;

public class CrashCourseCertification extends RRTechnicalCertification implements Certification {
	public CrashCourseCertification(String studentName,String courseName,int admissionTestMarks) {
		super(studentName,courseName,admissionTestMarks);
		
	}

	@Override
	public void generateRegistrationId() {
		// TODO Auto-generated method stub
		this.setRegistrationId(RRTechnicalCertification.counter);
		RRTechnicalCertification.counter+=1;

	}

	@Override
	public double calculateFee() {
		// TODO Auto-generated method stub
		int marks=super.getAdmissionTestMarks();
		double discount=0.0;
		if(marks>=90)
			discount=0.10;
		else if(marks>=75 && marks<=89)
			discount=0.05;
		else
			discount=0;
		double total_fee=Certification.crash_course_fee*((1-discount)+0.1236);
		return total_fee;
	}
}
