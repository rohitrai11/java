package exercise_34;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student s=new Student();
		s.setName("Alvin");
		s.setStudentId(1000);
		s.setTotalMarks(280);
		System.out.println("Student Details");
		System.out.println("Student ID : "+s.getStudentId());
		System.out.println("Name : "+s.getName());
		
		s.calculateGrade();
		s.calculateScholarshipAmount();
		System.out.println("Grade : "+s.getGrade());
		System.out.println("Scholarship Amount : "+s.getScholarshipAmount());
	}

}
