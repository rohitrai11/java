package Association;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterestCalculator i= new InterestCalculator(1,8.4f);
		FDAccount a=new FDAccount(1010,50000);
		a.updateBalance(i);
		System.out.println(a.getBalance());
		
	}

}
