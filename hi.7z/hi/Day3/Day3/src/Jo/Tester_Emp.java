package Jo;

public class Tester_Emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PermanentEmployee p=new PermanentEmployee(1001,"raj",10000,1500,3);
		p.calculateSalary();
		System.out.println(p.getSalary());

		ContractEmployee c=new ContractEmployee(1001,"riya",500,10);
		c.calculateSalary();
		System.out.println(c.getSalary());
		
		System.out.println(p instanceof Employee);
	}

}

