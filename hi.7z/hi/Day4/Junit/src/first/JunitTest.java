package first;
import junit.framework.Assert;

import org.junit.Test;
public class JunitTest {
@Test
public void designationTest(){
	Assert.assertTrue(new Employee().designation("RIYA",15000));
	Assert.assertFalse(new Employee().designation("RIYA",1000));
}
}
