package Jo;

public class ContractEmployee extends Employee{

	private double wage;
	private int hours;
	public double getWage() {
		return wage;
	}
	public void setWage(double wage) {
		this.wage = wage;
	}
	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	public ContractEmployee(int empid,String name,double wage,int hours){
		this.wage=wage;
		this.hours=hours;
		super.setEmpid(empid);
		super.setName(name);
	}
	public void calculateSalary(){
		double sal=this.wage*this.hours;
		super.setSalary(sal);
		//System.out.println(super.id);
	}
}
