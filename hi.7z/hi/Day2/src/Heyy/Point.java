package Heyy;

public class Point {
		public double x;
		public double y;
		
		public Point(){
			this.x=0;
			this.y=0;
		}
		
		public Point(double x,double y){
			this.x=x;
			this.y=y;
		}
		
		public void setx(double x){
			this.x=x;
		}
		
		public void sety(double y){
			this.y=y;
		}
		
		public double getX() {
			return x;
		}

		public double getY() {
			return y;
		}
	    public double distance(){
	    	double x1=getX();
	    	double y1=getY();
	    	double d=Math.sqrt((x1*x1)+(y1*y1));
	    	return d;
	    }
	    
	    public double distance(Point p){
	    	double x2=p.getX();
	    	double y2=p.getY();
	    	double d=Math.sqrt((this.x-x2)*(this.x-x2)+(this.y-y2)*(this.y-y2));
	    	return d;
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Point p=new Point();

	}

}
