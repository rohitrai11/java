package exercise_34;

public class Student {
	
	enum Grade{A,B,C,D,E};
	private int studentId;
	private String name;
	private int totalMarks;
	private Grade grade;
	private float scholarshipAmount;
	
	
	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getTotalMarks() {
		return totalMarks;
	}


	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}


	public Grade getGrade() {
		return grade;
	}


	public float getScholarshipAmount() {
		return scholarshipAmount;
	}
	
	
	public void calculateGrade(){
		int marks=this.getTotalMarks();
		if(marks>=250)
			this.grade=Grade.A;
		else if(marks>=200 && marks<250)
			this.grade=Grade.B;
		else if(marks>=175 && marks<200)
			this.grade=Grade.C;
		else if(marks>=150 && marks<175)
			this.grade=Grade.D;
		else
			this.grade=Grade.E;
	}
	
	public void calculateScholarshipAmount(){
		if(this.getGrade()==Grade.A)
			this.scholarshipAmount=5000;
		else if(this.getGrade()==Grade.B)
			this.scholarshipAmount=4000;
		else if(this.getGrade()==Grade.C)
			this.scholarshipAmount=3000;
		else if(this.getGrade()==Grade.D)
			this.scholarshipAmount=2000;
		else
			this.scholarshipAmount=0;
	}

}
