package exercise_22;

public class Validator {
	
	public void validate(Applicant applicant) throws Exception{
		if(this.isValidAge(applicant.getApplicantAge()) && this.isValidName(applicant.getApplicantName()) && this.isValidPost(applicant.getPostApplied())){
			System.out.println("All the values are valid.");
		}
		if(this.isValidAge(applicant.getApplicantAge())==false)
			throw new InvalidAgeException();
		if(this.isValidName(applicant.getApplicantName())==false)
			throw new InvalidNameException();
		if(this.isValidPost(applicant.getPostApplied())==false)
			throw new InvalidPostException();
	}
	
	public boolean isValidName(String name){
		if(name!=null && name!="")
			return true;
		return false;
	}
	
    public boolean isValidPost(String post){
    	if(post=="Probationary Officer" || post=="Assistant" || post=="Special Cadre Officer")
    		return true;
    	return false;
    }
    
    public boolean isValidAge(Integer age){
    	if(age>18 && age<35)
    		return true;
    	return false;
    }
}
