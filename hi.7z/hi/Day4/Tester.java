package exercise16;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UnderGraduateStudent ug=new UnderGraduateStudent("Mehul");
		ug.setTestScore(0, 70);
		ug.setTestScore(1, 69);
		ug.setTestScore(2, 71);
		ug.setTestScore(3, 55);
		ug.generateResult();
		System.out.println("Name :" +ug.getName()+ " Result :"+ug.getResult());
		GraduateStudent gs=new GraduateStudent("Ajay");
		gs.setTestScore(0, 70);
		gs.setTestScore(1, 69);
		gs.setTestScore(2, 71);
		gs.setTestScore(3, 55);
		gs.generateResult();
		System.out.println("Name :" +gs.getName()+ "  Result :"+gs.getResult());
	}

}
