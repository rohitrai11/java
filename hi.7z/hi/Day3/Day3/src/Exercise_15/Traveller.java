package Exercise_15;

public class Traveller {

	private String name;
	private String id;
	private double fare;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}

	public Traveller(String name,String id){
		this.name=name;
		this.id=id;
	}
	public void calculateFare(){
		if(this.getFare()==-1 || this.getFare()==0.0)
			this.setFare(2000);
		this.fare+=this.getFare()*0.1136;
	}
	
	public void displayDetails(){
		this.calculateFare();
		System.out.println("Traveller Details");
		System.out.println("Traveller name : "+this.getName());
		System.out.println("Traveller id : "+this.getId());
		System.out.println("Cost of Travel : "+this.getFare());
	}
}
