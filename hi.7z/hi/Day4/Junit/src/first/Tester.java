package first;

public class Tester {
public static void main(String[] args){
JunitTest j=new JunitTest();
j.designationTest();
}
}
