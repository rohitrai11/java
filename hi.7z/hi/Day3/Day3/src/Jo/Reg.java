package Jo;

class Reg extends New {
    Reg() {
    	super(4);
        System.out.println("Request for home loan");
    }
    public static void main(String args[]) {
    	
        @SuppressWarnings("unused")
		Reg obh=new Reg();
        
    }
}
