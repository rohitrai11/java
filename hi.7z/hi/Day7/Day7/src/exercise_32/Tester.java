package exercise_32;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> list=new ArrayList<>();
		
		Student s=new Student(101,"Ron",1);
		Student s1=new Student(102,"Angela",9);
		Student s2=new Student(103,"HAzel",5);
		Student s3=new Student(104,"David",3);
		Student s4=new Student(105,"Alan",4);
		Student s5=new Student(103,"Hazel",5);
		Student s6=new Student(101,"Ron",1);
		
		list.add(s);
		list.add(s1);
		list.add(s2);
		list.add(s3);
		list.add(s4);
		list.add(s5);
		list.add(s6);
		
		Set<Student> set=new TreeSet<>();
		set.addAll(list);
//		List<Student> list1=new ArrayList<>();
//		list.toArray();
//		for(Student stu:list){
//			if(!list1.contains(stu)){
//				list1.add(stu);
//			}
//		}
		System.out.println(set);
	}

}
