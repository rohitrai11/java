package application;
import application.CourseRegistration;
public class Tester {
	public static void main(String[] args) {
		// Code here
		CourseRegistration c= new CourseRegistration();
		c.setHostelRequired(false);
		c.setQualifyingMarks(70);
		c.setRegistrationId(12345);
		c.setStudentName("Raj");
		c.setCourseId(1009);
		int name=c.getCourseId();
		if (name==1001)
			c.setCourseFee(55000);
		else if(name==1002)
			c.setCourseFee(35675);
		else if(name==1003)
			c.setCourseFee(28300);
		else if(name==1004)
			c.setCourseFee(22350);
		else if(name==1005)
			c.setCourseFee(115000);
		else
			c.setCourseFee(0);
		c.calculateCourseFee();
	}
}
