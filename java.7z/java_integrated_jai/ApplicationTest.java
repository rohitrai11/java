package test;

import java.time.LocalDate;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import application.Application;
import application.Booking;
import application.Trainee;

public class ApplicationTest {
	Booking b = new  Booking();
	Trainee t = new Trainee();
	
	@Rule
	public ExpectedException ee = ExpectedException.none();
	
	@Test
	public void bookAssessmentInvalidBatchName()throws Exception{
		ee.expectMessage("Validator.INVALID_BATCH_NAME");
		b.setBatchName("JEE-rt1-cs");
		b.setAssessmentDate(LocalDate.now().plusDays(3));
		b.setAssessmentType("Objective");
		b.setCourseName("CSE");
		t.setEmailId("John_626262");
		t.setEmpNo(626262);
		new Application().bookAssessment(b);
		// Write the code to test
	}
	
	public void bookAssessmentInvalidEmailId()throws Exception{
		ee.expectMessage("Validator.INVALID_EMAIL_ID");
		b.setBatchName("JEE-RT2-CS");
		t.setEmailId("John_626289");
		new Application().bookAssessment(b);
		// Write the code to test
	}
	
	public void getAssessmentReportNotFound()throws Exception{
		ee.expectMessage("Application.NO_RECORDS_FOUND");
		b.setBatchName("IVS-RT1-CS");
		new Application().getAssessmentReport(b.getBatchName());
		// Write the code to test
	}
}
