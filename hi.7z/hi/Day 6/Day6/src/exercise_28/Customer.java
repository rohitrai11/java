package exercise_28;

public class Customer {
	
	private String customerName;
	private int applicableDiscount;
	
	public String getName(){
		return this.customerName;
	}
	public int getDiscount(){
		return this.applicableDiscount;
	}
	public void findDiscountAndName(String inputString){
		String s=inputString.trim();
		String list[]=s.split(":");
		if(list[0].equals("Regular")){
			this.applicableDiscount=10;
			System.out.println("Hi "+list[1]+"! "+this.getDiscount()+"% discount is applicable for you");}
		else if(list[0].equals("Privileged")){
			this.applicableDiscount=20;
			System.out.println("Hi "+list[1]+"! "+this.getDiscount()+"% discount is applicable for you");
	}
	}
}
